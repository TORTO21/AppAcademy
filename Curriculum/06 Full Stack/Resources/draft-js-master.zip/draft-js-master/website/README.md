Draft.js uses Docusaurus to maintain our documentation website. Please see the
[Docusaurus Documentation](https://docusaurus.io/) for more info.

# Run the server

The first time, get all the dependencies loaded via

```bash
yarn
```

in the root directory.

Then, run the server via

```bash
npm start
Open http://localhost:3000
```

Anytime you change the contents, just refresh the page and it's going to be
updated
