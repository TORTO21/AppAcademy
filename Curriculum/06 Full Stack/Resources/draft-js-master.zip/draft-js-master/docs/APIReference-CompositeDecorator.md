---
id: api-reference-composite-decorator
title: CompositeDecorator
---

## Advanced Topic Article

See the [advanced topic article on Decorators](/docs/advanced-topics-decorators.html#compositedecorator).
