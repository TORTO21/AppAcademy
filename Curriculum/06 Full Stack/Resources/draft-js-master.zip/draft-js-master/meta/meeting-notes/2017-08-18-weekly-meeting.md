# Draft.js Weekly 08/18/2017

Draft.js Weekly 08/18/201

Agenda Items:
* Intros
* React team maintainers mainly working on React 16.0 release (again)
* Upcoming stuff:
    * Month-long Draft.js improvement project in the works (still)
    * Issues bash being planned
* Continue Issue triage
