# Draft.js Weekly 08/04/2017

Agenda Items:

* Intros
* Anyone want to do one of these two tasks?
    *  “**[Draft.js] Update DraftEntity syntax in stateToMarkdown.js and stateFromMarkdown.js”** (internal task t15467849)
    * “**[Draft.js] File bug with Chrome for failure of `selection.addRange`**” (internal task t20310053)
    * If not @flarnie will delegate or do it myself this week.
* Continue Issue triage

