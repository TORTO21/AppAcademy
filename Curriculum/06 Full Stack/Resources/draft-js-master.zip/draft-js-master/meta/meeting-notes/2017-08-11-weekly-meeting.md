# Draft.js Weekly 08/11/2017

Agenda Items:

* Intros
* React team maintainers mainly working on React 16.0 release
* project being planned to bring more internal maintainers onto Draft.js for a
  1-month project
* Continue Issue triage
    * Closed some issues
    * Hoping to find second opinion on https://github.com/facebook/draft-js/issues/1334 but probably could accept proposed fix

Action Items:
* Making plan for continued work on releasing v0.11.0 and fixing open bugs
