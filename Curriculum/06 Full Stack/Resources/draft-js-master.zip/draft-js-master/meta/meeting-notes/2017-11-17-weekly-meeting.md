# Draft.js Weekly 11/17/17

* Continued work moving docs to Docusaurus
* Jest snapshot test conversion landed
* New maintainers
