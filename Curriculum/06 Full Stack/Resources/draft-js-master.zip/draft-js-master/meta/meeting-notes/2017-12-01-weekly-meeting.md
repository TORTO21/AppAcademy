# Draft.js Weekly 12/01/17

* Moving weekly meeting time so more folks can attend
* Update on Docusaurus migration
