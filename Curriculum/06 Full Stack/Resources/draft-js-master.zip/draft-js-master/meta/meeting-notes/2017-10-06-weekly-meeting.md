# Draft.js Weekly 10/06/17

* Discussed race conditions in Draft.js
