# Draft.js Weekly 3/24/17

* Upcoming 0.10.1 release
    * Last blocker is figuring out Entity deletion change - debugging issues with https://github.com/facebook/draft-js/pull/1065
