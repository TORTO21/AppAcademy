# Draft.js Weekly 5/19/17

* Draft v0.10.1 release went smoothly
