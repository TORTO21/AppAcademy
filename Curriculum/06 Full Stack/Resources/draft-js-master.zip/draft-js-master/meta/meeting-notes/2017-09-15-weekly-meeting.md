# Draft.js Weekly 09/15/17

* Proposal to support multiple entities per character - https://github (https://github.com/facebook/draft-js/pull/1315).com/facebook/draft-js/pull/1315 (https://github.com/facebook/draft-js/pull/1315)
  * Agreed that we aren't ready to merge this, need more time to consider, not sure when we would be
