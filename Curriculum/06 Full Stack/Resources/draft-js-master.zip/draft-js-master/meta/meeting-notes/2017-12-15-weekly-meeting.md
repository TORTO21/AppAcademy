# Draft.js Weekly 12/15/17

* Discussed issues which arise when using Draft.js with React's "async
  scheduling" enabled.
