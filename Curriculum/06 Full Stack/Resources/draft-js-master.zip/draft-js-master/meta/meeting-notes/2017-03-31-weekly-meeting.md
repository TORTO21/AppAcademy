# Draft.js Weekly 3/31/17

* Introduced Feature Flags
* Releasing from Master, instead of a release branch
    * Ideally this will speed up release process
* Discussion of how to automate syncing of Facebook changes to Draft to Github, and Github changes of Draft to Facebook.
