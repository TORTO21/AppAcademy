# Draft.js Weekly 3/17/17

Discussed https://github.com/facebook/draft-js/pull/1067
