# Draft.js Weekly 09/29/17

* Issues with landing PRs into FB - instructions for landing a PR written up
  internally
* Goal: Close or merge the 10 oldest PRs
    * Most interesting one so far: “Expose (most) transactions” - https://github.com/facebook/draft-js/pull/265




