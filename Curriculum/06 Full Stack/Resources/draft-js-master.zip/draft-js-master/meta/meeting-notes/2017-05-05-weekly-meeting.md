# Draft.js Weekly 5/05/17

* Internal testing of v0.10.1 going well
* Some folks out at JSConf EU
