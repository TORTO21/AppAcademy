# Draft.js Weekly 01/19/18

* Tried to fix CI, linting inconsistencies
