# Draft.js Weekly 2/17/17

* (again) Can we transfer the draftjs.com (http://draftjs.com/) domain to daniel lo nigro? (question for isaac?)
    * (https://github.com/facebook/draft-js/issues/317)

* Android/mobile web support update (flarnie)

**Last Week's Action Items:**
* DONE: Post statement about policy for API breaking changes (flarnie)

**Action items for next week:**
* Add these meeting notes in 'meta' directory (tylercraft or flarnie)
* Release v0.11.0@next (tylercraft)
* Create PRs for misc. Android bug fixes being tested internally (flarnie)
* Tasks related to internal FB updates for v0.10.0 syntax changes (flarnie)

