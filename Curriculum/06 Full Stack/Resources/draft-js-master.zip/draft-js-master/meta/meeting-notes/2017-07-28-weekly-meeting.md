# Draft.js Weekly 07/28/17

Agenda Items:

* Intros
* v0.11.0 alpha release 🎉 - https://github.com/facebook/draft-js/issues/1312
* Updates/questions on 'good first bug' tasks for new maintainers
* Look at *issues (not PRS this week)*
