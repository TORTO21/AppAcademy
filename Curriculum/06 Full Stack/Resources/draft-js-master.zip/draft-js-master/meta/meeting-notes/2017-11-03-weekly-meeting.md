# Draft.js Weekly 11/03/17

* Update on new experimental feature
* Migrating docs to Docusaurus - https://docusaurus.io/
* Tests being rewritten with Jest snapshots
