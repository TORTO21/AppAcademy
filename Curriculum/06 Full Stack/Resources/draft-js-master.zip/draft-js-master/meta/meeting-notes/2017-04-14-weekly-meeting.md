# Draft.js Weekly 4/14/17

* Continued discussion of automated syncing between Facebook and Github versions of Draft, to speed up release process
* How to enable external folks to help maintain Draft?
* Discussion of finding more Facebook maintainers
