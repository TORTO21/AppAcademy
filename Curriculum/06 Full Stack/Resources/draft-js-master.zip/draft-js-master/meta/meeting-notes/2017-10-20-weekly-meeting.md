# Draft.js Weekly 10/20/17

* Potentially onboarding external maintainers
* Upcoming project to add new improved features to Draft.js, within FB
* Bug Bash planning
