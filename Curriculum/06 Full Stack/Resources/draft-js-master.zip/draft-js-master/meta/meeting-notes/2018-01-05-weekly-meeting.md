# Draft.js Weekly 01/05/18

* Docusaurus migration almost complete, thanks @aadsm
* Update on experimental features
  * Planning on rolling out and testing within FB first, no plans to release to
    open source for at least next 6 months.

* Demo of debugger/playground tool - thanks @mitermayer & @juliankrispel
* 0.11.0 update?
  * Nobody is working on it, not sure when we will finish roll out
