# Draft.js Weekly 01/26/18

* Switching to biweekly for a while
* Discussed support for upcoming API changes in React in Draft.js
* No updates on experimental new features
* Docusaurus docs migration
  * Planning on looking into Netlify
  * Might land change before deciding about Netlify
* Why don't we support mobile web, and how to tell the community this
  * Really it's just Android we don't support
  * android behaves very differently from most desktop browsers
  * iOS behaves mostly like a desktop browser
  * write one really good response and link to that
* Discussed internal PR to expose start/end of positions of decorated
  component within a contentBlock (D6712533)
  * lgtm!
* Discussed more potential new maintainers
* How to fix/import PRs which don't give maintainers permission to
  push to them?
* There is still a bug with selecting and typing the same character;
  * Flarnie will look at this again

