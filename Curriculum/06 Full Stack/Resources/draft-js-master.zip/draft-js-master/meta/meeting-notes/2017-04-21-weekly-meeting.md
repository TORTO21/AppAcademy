# Draft.js Weekly 4/21/17

* Discussed fixes for bugs
* [Gboard auto-translate](https://www.theverge.com/2017/3/9/14864048/google-gboard-keyboard-android-google-translate)
  * maybe look into how this affects Draft
          * also look at if/when this would be on Android


