# Draft.js Weekly 5/26/17

* Planning a bug-bash/issues triage session in June
* Posting internally at FB to recruit more maintainers
