# Draft.js Weekly 6/02/17

* Discussed ongoing fix to work better with React Fiber
* Set date for internal FB bug/issues bash in mid June
* Onboarding new internal maintainers
