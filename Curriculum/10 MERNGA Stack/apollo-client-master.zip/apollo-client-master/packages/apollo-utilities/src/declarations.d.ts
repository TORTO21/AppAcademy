declare module 'fast-json-stable-stringify';
