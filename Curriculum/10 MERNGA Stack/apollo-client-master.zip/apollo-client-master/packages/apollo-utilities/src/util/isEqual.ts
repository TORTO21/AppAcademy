export { equal as isEqual } from '@wry/equality';
