module.exports = {
  ...require('../../config/jest.config.settings'),
};
