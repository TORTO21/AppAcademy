export const version = "2.6.0-beta.8"
