import { rollup } from '../../config/rollup.config';

export default rollup({
  name: 'apollo-cache',
});
