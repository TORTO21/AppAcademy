module.exports = {
  rootDir: '.',
  projects: ['<rootDir>/packages/*'],
};
