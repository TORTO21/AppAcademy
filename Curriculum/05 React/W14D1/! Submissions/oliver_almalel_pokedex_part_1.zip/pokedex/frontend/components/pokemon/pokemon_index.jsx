import React from 'react'

class PokemonIndex extends React.Component {

  componentDidMount() {
    this.props.requestAllPokemon();
  }
  
  render() {
    const pokemonLis = this.props.pokemon.map((pokemonLi, idx) => {
      return <li key={idx}>
            {pokemonLi.name}
            <img src={pokemonLi.image_url}
                 alt={pokemonLi.name}
                 width={300}
                 height={300} />
            </li>
    });
    return (
      <ul>
        {pokemonLis}
      </ul>
    );
  }
}

export default PokemonIndex