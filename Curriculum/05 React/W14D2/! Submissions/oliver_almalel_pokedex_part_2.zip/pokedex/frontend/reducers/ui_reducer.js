export const uiReducer = (state, action) => {
  switch(action.type) {


    default: 
      return state
  }
}