module.exports = {
  MONGO_URI: "mongodb+srv://TORTO21:pinners3@cluster00-ktmgw.mongodb.net/blogs?retryWrites=true&w=majority",
  SECRET_OR_KEY: "pinners3"
};